<?php
header("Content-Type: text/html; charset=utf-8");
/******************************************************************************
	Tarefa 9 - Desafio: (use o preferir WHILE ou FOR)
		Crie uma função chamada listaNumeros, ela recebe o parametro $tipoNumero
		que pode ser "par" ou "ímpar". SE é passado "par", a função deve mostrar 
		todos os números pares entre 1 e 50, SE é passado "ímpar", deve mostrar
		todos os números ímpares entre 1 e 50.
******************************************************************************/













?>