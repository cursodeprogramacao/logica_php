<?php
header("Content-Type: text/html; charset=utf-8");
/***************************************************************** 
	Tarefa 3: (use WHILE) 
		Crie um programa que faz a contagem regressiva para
		o lançamento de um foguete. Deve mostrar primeiro o 10 e 
		por último o 0;
*****************************************************************/










?>