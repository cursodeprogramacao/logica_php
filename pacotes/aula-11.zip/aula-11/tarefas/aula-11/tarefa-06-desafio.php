<?php
header("Content-Type: text/html; charset=utf-8");
/************************************************************************ 
	Tarefa 6 - Desafio: (USE WHILE)
		Crie um programa que mostre somente os números ímpares entre 1 e 100
		Dica: O código vai ser muito parecido com o mostrado na tarefa 2, 
		na verdade só precisa trocar um caracter. Qual será?
*************************************************************************/



















?>
