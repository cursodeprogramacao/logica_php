<?php
header("Content-Type: text/html; charset=utf-8");
/**************************************************************************** 
	Tarefa 10 - Desafio: (USE FOR)
		Os comandos de repetição são comumente usados para a criação de desenhos,
		gráficos e animações. Nesse desafio você deve criar essa figura usando
		asteriscos e o comando FOR: http://cl.ly/image/2T1A3d3t1t1Z
		Dicas: O for vai até 1000 e cada linha dessa figura tem 50 asteriscos
*****************************************************************************/
















?>
