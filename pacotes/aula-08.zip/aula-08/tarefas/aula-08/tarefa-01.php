<?php
header("Content-Type: text/html; charset=utf-8");
/************************************************************************ 
	Tarefa 1: 
		Crie uma função chamada termostato. Essa função deve receber um 
		número no parâmetro temperatura. Se a temperatura for menor 
		que zero, a função retorna a mensagem "Temperatura Negativa". 
		Se for maior que zero, retorna a mensagem "Temperatura positiva"
		- Teste sua função com as temperaturas 0, -8 e 25.
************************************************************************/







?>