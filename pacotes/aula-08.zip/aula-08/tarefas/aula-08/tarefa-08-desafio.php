<?php
header("Content-Type: text/html; charset=utf-8");
/********************************************************************* 
	Tarefa 8 - Desafio: 
		Crie uma função com o nome que preferir. Ela vai receber o
		parâmetro estado, e deve retornar a região que esse estado
		pertence. Se ela receber SP por exemplo, deve retornar Sudeste.
**********************************************************************/

















?>
