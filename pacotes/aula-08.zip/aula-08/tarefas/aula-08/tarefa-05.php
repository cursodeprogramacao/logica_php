<?php
header("Content-Type: text/html; charset=utf-8");
/********************************************************* 
	Tarefa 5: 
		Crie uma função chamada validarSenha. Se a senha
		for "123456", a função retorna a mensagem "Login
		efetuado com sucesso", senão, retorna a mensagem
		"Senha inválida".
**********************************************************/










?>