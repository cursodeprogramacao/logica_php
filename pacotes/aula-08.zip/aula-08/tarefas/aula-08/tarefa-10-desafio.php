<?php
header("Content-Type: text/html; charset=utf-8");
/***********************************************************************
	Tarefa 10 - Desafio: 
		Crie uma função chamada validarCampo. Ela recebe uma string como
		parâmetro. Se a string for maior que 4, deve retornar a mensagem
		"Campo deve ter no máximo 4 letras".
************************************************************************/
















?>