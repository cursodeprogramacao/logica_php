<?php
header("Content-Type: text/html; charset=utf-8");
/********************************************************************** 
	Tarefa 2: 
		Crie uma função chamada boletimEscolar. Essa função deve 
		receber um número no parâmetro nota. As notas válidas são 
		de 0 a 10. Se o usuário digitar uma nota inválida a função 
		deve retornar "Nota inválida". Depois de receber uma nota 
		válida, a função deve retornar "Aprovado" ou "Reprovado". 
		A média para aprovação é 60%. 
		- Teste sua função com as notas -5, 0, 7, 3 e 19
**********************************************************************/








?>