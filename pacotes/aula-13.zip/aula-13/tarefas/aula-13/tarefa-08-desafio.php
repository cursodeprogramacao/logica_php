<?php
header("Content-Type: text/html; charset=utf-8");
/******************************************************************************
	Tarefa 8 - Desafio:
		Crie uma função que retorne um array contendo vários arrays do tipo hash.
		Será muito parecido com a tarefa 4, porém você deve escolher outros tipos
		de dados, ao invés de times de futebol, fique a vontade para escolher.
		Um exemplo seria, retornar os dados de uma agenda telefônica, e retorno
		do loop seria algo como:
			Joana da Silva - Telefone: 3131-3030 - Celular: 9988-7788
			Manoel Souza   - Telefone: 3166-3070 - Celular: 9955-7755
			Silvio Santos  - Telefone: 4531-4530 - Celular: 9945-4588

******************************************************************************/











?>