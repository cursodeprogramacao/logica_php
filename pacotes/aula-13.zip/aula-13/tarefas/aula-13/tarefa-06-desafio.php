<?php
header("Content-Type: text/html; charset=utf-8");
/********************************************************************** 
	Tarefa 6 - Desafio: (usando arrays)
		Crie a função mesPeloNumero($numeroMes). Essa função vai receber
		um número e retornar o nome do mês. Se receber 1 retorna Janeiro, 
		e se receber 12 retorna Dezembro.
		- Teste a sua função com os números 1, 5, 9 e 12.
		
		Dica: Pra resolver o problema mais rápido, use a função que você
		mesmo criou no desafio 5.

***********************************************************************/















?>
