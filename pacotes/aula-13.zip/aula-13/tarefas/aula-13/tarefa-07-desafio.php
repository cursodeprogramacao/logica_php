<?php
header("Content-Type: text/html; charset=utf-8");
/********************************************************************** 
	Tarefa 7 - Desafio:
		Crie uma função com o nome que preferir, essa função vai receber
		um array de números como parâmetro, e retornar um array contendo
		em cada posição, o dobro do número do array anterior. 
		Exemplo: A função recebeu o array(3, 15, 23) e vai retornar um
		array(6, 30, 46). Veja que cada número do segundo array é o drobro
		dos números do primeiro array.
***********************************************************************/















?>
