<?php
header("Content-Type: text/html; charset=utf-8");
/**************************************************************************** 
	Tarefa 9 - Desafio:
		Crie uma função chamada somarArray, ela deve receber um array de números
		como parâmetro e retornar o mesmo array com uma posição a mais, que
		deverá ter a soma nela. 
		Exemplo: recebe array(4, 7, 9) e retorna array(4, 7, 9, 20), pois
		4 + 7 + 9 = 20.

		Dica: array_push vai te ajudar a resolver.
*****************************************************************************/
















?>
