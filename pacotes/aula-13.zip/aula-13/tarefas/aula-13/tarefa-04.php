<?php
header("Content-Type: text/html; charset=utf-8");
/***************************************************************** 
	Tarefa 4: 
		Crie uma função chamada tabelaBrasileirao, que retorne um
		array contendo em cada posição um hash com o nome e pontuação
		do time. Para testar sua função, você deve usar o foreach
		e o resultado final deve ser:
			Cruzeiro : 46 pontos
			Botafogo : 42 pontos
			Grêmio : 37 pontos 
*****************************************************************/










?>