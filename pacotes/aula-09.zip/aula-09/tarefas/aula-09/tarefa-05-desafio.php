<?php
header("Content-Type: text/html; charset=utf-8");
/****************************************************************** 
	Tarefa 5 - Desafio: (USE SWITCH CASE)
		Crie uma função com o nome que preferir. Ela vai receber o
		parâmetro estado, e deve retornar a região que esse estado
		pertence. Se ela receber SP por exemplo, deve retornar Sudeste.
		- Faça testes com os estados SP, BA, RS e AM.
*******************************************************************/



















?>
