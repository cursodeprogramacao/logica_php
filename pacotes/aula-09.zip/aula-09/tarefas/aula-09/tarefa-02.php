<?php
header("Content-Type: text/html; charset=utf-8");
/********************************************************************** 
	Tarefa 2: (USE SWITCH CASE)
		Crie um função que recebe um número referente ao mês e retorna
		o nome do mês equivalente. 1 para Janeiro, 2 para Fevereiro, 3 para
		março e assim por diante, até 12 para dezembro.
		- Teste com os valores 3, 8, 12 e 15.
**********************************************************************/










?>