<?php
header("Content-Type: text/html; charset=utf-8");
/************************************************************************** 
	Tarefa 6 - Desafio: (USE SWITCH CASE)
		Agora vamos fazer um programa que verifica a pontuação dos times
		do campeonato brasileiro. A função deve receber o nome do time
		como parâmetro e mostrar uma mensagem com o nome do time, pontuação
		e qual a sua colocação. 
			Ex. mensagem: "O Cruzeiro tem 31 pontos e é o 1o colocado"
		A tabela para consulta está disponível em: http://bit.ly/brasileirao13
		- Faça testes com o Cruzeiro, Flamengo, Bahia e Náutico.
**************************************************************************/

















?>
