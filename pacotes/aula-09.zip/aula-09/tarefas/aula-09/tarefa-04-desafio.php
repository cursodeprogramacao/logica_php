<?php
header("Content-Type: text/html; charset=utf-8");
/************************************************************************
	Tarefa 4 - Desafio: (USE SWITCH CASE)
		Crie uma função que recebe um número de 1 a 7 e informa o dia da
		semana correspondente, sendo domingo o dia de número 1. Se o número
		não corresponder a um dia da semana, é mostrado uma mensagem avisando
		que o número é inválido.
		- Teste sua função com 1, 2, 3, 4, 5, 6, 7, 8
*************************************************************************/













?>