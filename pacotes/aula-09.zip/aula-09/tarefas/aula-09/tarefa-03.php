<?php
header("Content-Type: text/html; charset=utf-8");
/***************************************************************** 
	Tarefa 3: (USE SWITCH CASE) 
		Agora nós vamos criar um controle remoto. Quando o número
		do canal for digitado, ele deve exibir o nome da emissora.
		- Faça testes para que sejam exibidos os canais SBT e Globo
*****************************************************************/













?>